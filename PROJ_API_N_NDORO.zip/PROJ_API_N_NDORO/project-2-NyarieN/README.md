[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/290U_JNB)
Project 2 , read me file
The NWU Tech Trends Telemetry API project tracks and reports time and cost savings from automation, grouped by project and client, using telemetry recorded through a RESTful API .The API provides endpoints to generate detailed reports on time and cost savings, which can be filtered by project, client, and date range. With cloning the GitHub repository, configuring the database, setting  up JWT authentication, and deploying the API to Azure, to ensure that no credentials are stored in the source code.

 Stakeholders can use the API's CRUD(Create , Retrieve/Read, Update and delete) operations to manage telemetry data and secure API access with JWT authentication.
Stakeholders can evaluate how much time and money the automation has saved compared to the manual process of doing the desired project 
Phelps in making informed decisions
Track automation overtime to ensure that the automation delivers expected and best results and to look for any loops to see if there is a need for improving or if further optimization is need 
Stakeholders may also use the overall impact of automation of the organization’s bottom line 
