﻿using TelemetryPortal_MVC.Data;
using TelemetryPortal_MVC.Models;
using System.Collections.Generic;
using System.Linq;

namespace TelemetryPortal_MVC.Repository
{
    public class ClientsRepository
    {
        private readonly TechtrendsContext _context = new TechtrendsContext();
       
        public IEnumerable<Clients> GetAll()
        {
            return _context.Clients.ToList();
        }

        public Clients GetById(Guid id)
        {
            return _context.Clients.Find(id);
        }

        public void Add(Clients client)
        {
            _context.Clients.Add(client);
        }

        public void Update(Clients client)
        {
            _context.Clients.Update(client);
        }

        public void Remove(Clients client)
        {
            _context.Clients.Remove(client);
        }

        public bool Exists(Guid id)
        {
            return _context.Clients.Any(e => e.ClientId == id);
        }
    }
}

