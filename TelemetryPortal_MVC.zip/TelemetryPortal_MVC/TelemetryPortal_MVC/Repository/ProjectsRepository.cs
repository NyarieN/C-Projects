﻿using TelemetryPortal_MVC.Data;
using TelemetryPortal_MVC.Models;
using System.Collections.Generic;
using System.Linq;

namespace TelemetryPortal_MVC.Repository
{
    public class ProjectsRepository
    {
        private readonly TechtrendsContext _context = new TechtrendsContext();

        public IEnumerable<Projects> GetAll()
        {
            return _context.Projects.ToList();
        }

        public Projects GetById(Guid id)
        {
            return _context.Projects.Find(id);
        }

        public void Add(Projects project)
        {
            _context.Projects.Add(project);
        }

        public void Update(Projects project)
        {
            _context.Projects.Update(project);
        }

        public void Remove(Projects project)
        {
            _context.Projects.Remove(project);
        }

        public bool Exists(Guid id)
        {
            return _context.Projects.Any(e => e.ProjectId == id);
        }
    }
}

